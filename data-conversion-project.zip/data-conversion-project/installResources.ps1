# Skrypt do instalacji wymaganych bibliotek Pythona
pip install pyinstaller pyyaml pyqt5
