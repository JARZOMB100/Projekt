import sys
import json
import yaml
import xml.etree.ElementTree as ET
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QFileDialog, QLabel

def parse_args(args):
    if len(args) != 3:
        print("Usage: program.exe pathFile1.x pathFile2.y")
        sys.exit(1)
    return args[1], args[2]

def read_json(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

def write_json(data, file_path):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

def read_yaml(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
    return data

def write_yaml(data, file_path):
    with open(file_path, 'w') as file:
        yaml.dump(data, file)

def read_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    return root

def write_xml(data, file_path):
    tree = ET.ElementTree(data)
    tree.write(file_path)

class DataConverterApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        self.label = QLabel("Choose files to convert", self)
        layout.addWidget(self.label)

        self.btnOpenFile = QPushButton("Open Input File", self)
        self.btnOpenFile.clicked.connect(self.openFileNameDialog)
        layout.addWidget(self.btnOpenFile)

        self.btnSaveFile = QPushButton("Save Output File", self)
        self.btnSaveFile.clicked.connect(self.saveFileDialog)
        layout.addWidget(self.btnSaveFile)

        self.btnConvert = QPushButton("Convert", self)
        self.btnConvert.clicked.connect(self.convertFiles)
        layout.addWidget(self.btnConvert)

        self.setLayout(layout)
        self.setWindowTitle("Data Converter")
        self.show()

    def openFileNameDialog(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getOpenFileName(self, "Open Input File", "", "All Files (*);;JSON Files (*.json);;YAML Files (*.yml);;XML Files (*.xml)", options=options)
        if fileName:
            self.inputFile = fileName
            self.label.setText(f"Input File: {fileName}")

    def saveFileDialog(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getSaveFileName(self, "Save Output File", "", "All Files (*);;JSON Files (*.json);;YAML Files (*.yml);;XML Files (*.xml)", options=options)
        if fileName:
            self.outputFile = fileName
            self.label.setText(f"Output File: {fileName}")

    def convertFiles(self):
        input_file = self.inputFile
        output_file = self.outputFile
        if input_file.endswith('.json') and output_file.endswith('.json'):
            data = read_json(input_file)
            write_json(data, output_file)
        elif input_file.endswith('.yml') and output_file.endswith('.yml'):
            data = read_yaml(input_file)
            write_yaml(data, output_file)
        elif input_file.endswith('.xml') and output_file.endswith('.xml'):
            data = read_xml(input_file)
            write_xml(data, output_file)
        else:
            self.label.setText("Unsupported file format")
            return
        self.label.setText(f"Data converted from {input_file} to {output_file}")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ex = DataConverterApp()
    sys.exit(app.exec_())
